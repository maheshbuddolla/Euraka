package com.example.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class EmpConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpConsumerApplication.class, args);
	}
}
